import { useState } from 'react';
import { useApp } from '../context';
import { motion } from 'framer-motion';

export default function Admin() {
  const { data, refreshData } = useApp();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'settings' | 'packages' | 'messages' | 'stats'>('settings');
  const [saveStatus, setSaveStatus] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const result = await res.json();
      if (result.success) {
        setIsAuthenticated(true);
      } else {
        setError('Hatalı şifre');
      }
    } catch(err) {
      setError('Bağlantı hatası');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setSaveStatus('Kaydediliyor...');
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data.settings)
      });
      refreshData();
      setSaveStatus('Başarıyla kaydedildi!');
      setTimeout(() => setSaveStatus(''), 3000);
    } catch {
      setSaveStatus('Hata oluştu');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center p-4">
        <div className="glass-dark p-8 rounded-2xl w-full max-w-md">
          <h2 className="text-2xl text-gold-500 font-bold text-center mb-6 uppercase tracking-widest">Yönetici Girişi</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <input 
              type="password" 
              placeholder="Şifre" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold-500"
            />
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button type="submit" className="w-full py-3 bg-gold-500 text-black rounded-lg font-bold tracking-widest uppercase text-sm hover:bg-white transition-all">
              Giriş Yap
            </button>
            <p className="text-white/30 text-xs text-center">Demo şifresi: avex2026</p>
          </form>
        </div>
      </div>
    );
  }

  if (!data) return <div className="p-8 text-white">Yükleniyor...</div>;

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Sidebar */}
      <div className="w-64 glass-dark h-screen border-r border-white/10 p-6 flex flex-col">
        <div className="text-2xl font-bold tracking-widest text-gold-500 mb-12">AVEX ADMIN</div>
        <div className="flex flex-col gap-2">
          {['settings', 'packages', 'messages', 'stats'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`text-left px-4 py-3 rounded-lg uppercase tracking-wider text-sm transition-colors ${activeTab === tab ? 'bg-gold-500 text-black font-medium' : 'hover:bg-white/5'}`}
            >
              {tab === 'settings' && 'Ayarlar'}
              {tab === 'packages' && 'Paketler'}
              {tab === 'messages' && 'Mesajlar'}
              {tab === 'stats' && 'İstatistikler'}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-10 overflow-y-auto">
        {saveStatus && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed top-6 right-6 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 font-medium"
          >
            {saveStatus}
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-3xl font-bold mb-8 tracking-wider">Site Ayarları</h2>
            <form onSubmit={handleSaveSettings} className="space-y-6 max-w-2xl glass-dark p-8 rounded-2xl border border-white/5">
              <div>
                <label className="block text-sm uppercase tracking-widest text-white/50 mb-2">Hero Başlık</label>
                <input 
                  type="text" 
                  value={data.settings.heroTitle}
                  onChange={e => { data.settings.heroTitle = e.target.value; refreshData(); }}
                  className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white"
                />
              </div>
              <div>
                <label className="block text-sm uppercase tracking-widest text-white/50 mb-2">Hero Alt Başlık</label>
                <input 
                  type="text" 
                  value={data.settings.heroSubtitle}
                  onChange={e => { data.settings.heroSubtitle = e.target.value; refreshData(); }}
                  className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white"
                />
              </div>
              <button type="submit" className="py-3 px-8 bg-gold-500 text-black rounded-lg font-bold tracking-widest uppercase text-sm hover:bg-white transition-all">
                Kaydet
              </button>
            </form>
          </motion.div>
        )}

        {activeTab === 'messages' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-3xl font-bold mb-8 tracking-wider">Gelen Mesajlar</h2>
            <div className="space-y-4">
              {data.messages.length === 0 ? (
                <p className="text-white/50">Henüz mesaj yok.</p>
              ) : (
                data.messages.map(msg => (
                  <div key={msg.id} className="glass-dark p-6 rounded-xl border border-white/5 flex flex-col gap-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-lg text-gold-500">{msg.name}</h4>
                        <div className="text-sm text-white/50 flex gap-4 mt-1">
                          <span>{msg.email}</span>
                          <span>{msg.phone}</span>
                        </div>
                      </div>
                      <div className="text-xs text-white/30">{new Date(msg.date).toLocaleString('tr-TR')}</div>
                    </div>
                    <p className="bg-black/30 p-4 rounded-lg font-light leading-relaxed">{msg.message}</p>
                    <button 
                      onClick={async () => {
                        await fetch(`/api/messages/${msg.id}`, { method: 'DELETE' });
                        refreshData();
                      }}
                      className="text-red-500 self-end text-sm uppercase tracking-widest hover:text-red-400"
                    >
                      Sil
                    </button>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'stats' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-3xl font-bold mb-8 tracking-wider">İstatistikler</h2>
            <div className="grid grid-cols-2 gap-6 max-w-2xl">
              <div className="glass-dark p-8 rounded-2xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-5xl text-gold-500 font-bold mb-2">{data.stats.views}</div>
                <div className="text-sm uppercase tracking-widest text-white/50">Sayfa Görüntülenmesi</div>
              </div>
              <div className="glass-dark p-8 rounded-2xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-5xl text-gold-500 font-bold mb-2">{data.stats.submissions}</div>
                <div className="text-sm uppercase tracking-widest text-white/50">Form Gönderimi</div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'packages' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-3xl font-bold mb-8 tracking-wider">Paket Yönetimi</h2>
            <p className="text-white/50">Paketleri düzenlemek için src/server.ts içerisindeki data.json güncellenmelidir. Bu demo için statik bırakılmıştır.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
