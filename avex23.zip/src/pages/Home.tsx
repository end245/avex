import { useState, useEffect } from 'react';
import { useApp } from '../context';
import Loader from '../components/Loader';
import Hero from '../components/Hero';
import Services from '../components/Services';
import Packages from '../components/Packages';
import Gallery from '../components/Gallery';
import Brands from '../components/Brands';
import Stats from '../components/Stats';
import Timeline from '../components/Timeline';
import Testimonials from '../components/Testimonials';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

export default function Home() {
  const { data, loading } = useApp();
  const [showContent, setShowContent] = useState(false);

  // Prevent scroll during loading
  useEffect(() => {
    if (!showContent) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => { document.body.style.overflow = 'auto'; };
  }, [showContent]);

  if (loading || !data) {
    return <div className="h-screen bg-black flex items-center justify-center text-gold-500 uppercase tracking-widest text-sm">Yükleniyor...</div>;
  }

  return (
    <main className="bg-black min-h-screen text-white">
      <Loader onComplete={() => setShowContent(true)} />
      
      {showContent && (
        <>
          <Hero title={data.settings.heroTitle} subtitle={data.settings.heroSubtitle} />
          <Services />
          <Stats />
          <Packages />
          <Gallery />
          <Brands />
          <Timeline />
          <Testimonials />
          <Contact />
          <Footer />
        </>
      )}
    </main>
  );
}
