import { createContext, useContext, useEffect, useState } from 'react';
import { AppData, AppSettings, Package, GalleryItem, Testimonial } from './types';

interface AppContextType {
  data: AppData | null;
  loading: boolean;
  refreshData: () => void;
}

const AppContext = createContext<AppContextType>({ data: null, loading: true, refreshData: () => {} });

export const useApp = () => useContext(AppContext);

export const AppProvider = ({ children }: { children: React.ReactNode }) => {
  const [data, setData] = useState<AppData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch('/api/data');
      if (response.ok) {
        const result = await response.json();
        setData(result);
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    // Add page view
    fetch('/api/stats/view', { method: 'POST' }).catch(() => {});
  }, []);

  return (
    <AppContext.Provider value={{ data, loading, refreshData: fetchData }}>
      {children}
    </AppContext.Provider>
  );
};
