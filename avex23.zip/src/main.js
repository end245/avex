import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// --- PRELOADER ---
window.addEventListener('load', () => {
  const preloader = document.getElementById('preloader');
  if (preloader) {
    setTimeout(() => {
      preloader.style.opacity = '0';
      preloader.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
      preloader.style.transform = 'scale(1.03)';
      setTimeout(() => {
        preloader.style.display = 'none';
      }, 700);
    }, 1800);
  }
});

// --- MOBILE MENU ---
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');
const mobileMenuLinks = document.querySelectorAll('.mobile-nav-link');
const menuIconOpen = document.getElementById('menu-icon-open');
const menuIconClose = document.getElementById('menu-icon-close');

function toggleMobileMenu(forceState) {
  if (!mobileMenu) return;
  const isCurrentlyOpen = !mobileMenu.classList.contains('hidden');
  const shouldOpen = typeof forceState === 'boolean' ? forceState : !isCurrentlyOpen;

  if (shouldOpen) {
    mobileMenu.classList.remove('hidden');
    if (menuIconOpen) menuIconOpen.classList.add('hidden');
    if (menuIconClose) menuIconClose.classList.remove('hidden');
  } else {
    mobileMenu.classList.add('hidden');
    if (menuIconOpen) menuIconOpen.classList.remove('hidden');
    if (menuIconClose) menuIconClose.classList.add('hidden');
  }
}

if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleMobileMenu();
  });

  mobileMenuLinks.forEach(link => {
    link.addEventListener('click', () => {
      toggleMobileMenu(false);
    });
  });

  document.addEventListener('click', (e) => {
    if (mobileMenu && !mobileMenu.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
      toggleMobileMenu(false);
    }
  });
}

// --- 3D CAR SHOWROOM ---
const container = document.getElementById('webgl-container');
let currentModelGroup = null;
let controls = null;
let camera = null;
let renderer = null;

function updateCameraViewport() {
  if (!container || !camera || !renderer || !controls) return;
  const width = container.clientWidth;
  const height = container.clientHeight;
  const aspect = width / height;

  camera.aspect = aspect;

  // Adapt camera position & distance according to aspect ratio
  if (aspect < 0.8) {
    // Smartphone vertical portrait
    camera.position.set(5.6, 2.2, 6.2);
    camera.fov = 48;
    controls.minDistance = 4.0;
    controls.maxDistance = 8.5;
  } else if (aspect < 1.2) {
    // Tablet or small screen
    camera.position.set(4.8, 2.0, 5.2);
    camera.fov = 46;
    controls.minDistance = 3.6;
    controls.maxDistance = 8.0;
  } else {
    // Desktop landscape
    camera.position.set(4.0, 1.8, 4.5);
    camera.fov = 45;
    controls.minDistance = 3.2;
    controls.maxDistance = 7.5;
  }

  camera.updateProjectionMatrix();
  renderer.setSize(width, height);
}

if (container) {
  const scene = new THREE.Scene();
  
  // Camera
  camera = new THREE.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    100
  );

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  // Controls
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.05;
  controls.maxPolarAngle = Math.PI / 2 - 0.05; // don't go below ground
  controls.enablePan = false; // Keep vehicle centered
  controls.enableZoom = false; // Prevent stuck pinch zoom on mobile devices
  controls.autoRotate = true;
  controls.autoRotateSpeed = 0.8;

  // Initialize responsive viewport
  updateCameraViewport();

  // Studio Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
  scene.add(ambientLight);

  const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
  keyLight.position.set(5, 6, 5);
  keyLight.castShadow = true;
  scene.add(keyLight);

  const fillLight = new THREE.DirectionalLight(0xffffff, 1.8);
  fillLight.position.set(-5, 4, -3);
  scene.add(fillLight);

  const rimLight = new THREE.DirectionalLight(0xffffff, 2.0);
  rimLight.position.set(0, 5, -5);
  scene.add(rimLight);

  // Studio Floor Shadow Disc
  const shadowGeo = new THREE.PlaneGeometry(8, 8);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.5,
    depthWrite: false
  });
  const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = -0.79;
  scene.add(shadowPlane);

  // Load single BMW model: carbmw.glb
  const loader = new GLTFLoader();
  const loadingIndicator = document.getElementById('car-loading');

  function loadCar() {
    if (loadingIndicator) loadingIndicator.style.display = 'flex';

    if (currentModelGroup) {
      scene.remove(currentModelGroup);
      currentModelGroup = null;
    }

    loader.load(
      '/carbmw.glb',
      (gltf) => {
        const model = gltf.scene;

        // Auto-compute bounding box to center & scale carbmw.glb perfectly
        const initialBox = new THREE.Box3().setFromObject(model);
        const size = initialBox.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);

        // Target vehicle size in 3D world
        const targetSize = 4.2;
        const scale = maxDim > 0 ? targetSize / maxDim : 1;
        model.scale.set(scale, scale, scale);

        // Center on X and Z, align base to floor ground
        const scaledBox = new THREE.Box3().setFromObject(model);
        const center = scaledBox.getCenter(new THREE.Vector3());
        const groundY = -0.78;

        model.position.x = -center.x;
        model.position.z = -center.z;
        model.position.y = groundY - scaledBox.min.y;

        model.traverse((child) => {
          if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
            if (child.material) {
              child.material.envMapIntensity = 1.3;
              child.material.needsUpdate = true;
            }
          }
        });

        currentModelGroup = model;
        scene.add(model);
        if (loadingIndicator) loadingIndicator.style.display = 'none';
      },
      undefined,
      (error) => {
        console.warn('GLTF load error:', error);
        if (loadingIndicator) loadingIndicator.style.display = 'none';
      }
    );
  }

  // Initial car load
  loadCar();

  // Animation Loop
  function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  }
  animate();

  // Resize handler
  window.addEventListener('resize', () => {
    updateCameraViewport();
  });
  window.addEventListener('orientationchange', () => {
    setTimeout(updateCameraViewport, 150);
  });
}

// --- STATS COUNTERS ---
const counterElements = document.querySelectorAll('.counter-val');
let animatedStats = false;

function animateCounters() {
  if (animatedStats) return;
  animatedStats = true;

  counterElements.forEach(el => {
    const target = parseInt(el.getAttribute('data-target') || '0', 10);
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 2000;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = target / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(current) + suffix;
    }, stepTime);
  });
}

const statsSection = document.getElementById('stats');
if (statsSection) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounters();
      }
    });
  }, { threshold: 0.2 });
  observer.observe(statsSection);
}

// --- GALLERY FILTER & LIGHTBOX ---
const filterBtns = document.querySelectorAll('.gallery-filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const filter = btn.getAttribute('data-filter');
    filterBtns.forEach(b => {
      b.classList.remove('bg-white', 'text-black');
      b.classList.add('bg-white/5', 'text-white/70');
    });
    btn.classList.add('bg-white', 'text-black');
    btn.classList.remove('bg-white/5', 'text-white/70');

    galleryItems.forEach(item => {
      const cat = item.getAttribute('data-category');
      if (filter === 'all' || cat === filter) {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });
  });
});

galleryItems.forEach(item => {
  item.addEventListener('click', () => {
    const img = item.querySelector('img');
    if (img && lightbox && lightboxImg) {
      lightboxImg.src = img.src;
      lightbox.classList.remove('hidden');
    }
  });
});

if (lightboxClose && lightbox) {
  lightboxClose.addEventListener('click', () => {
    lightbox.classList.add('hidden');
  });
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) {
      lightbox.classList.add('hidden');
    }
  });
}

// --- BOOKING FORM & WHATSAPP INTEGRATION ---
const bookingForm = document.getElementById('booking-form');
const formSuccess = document.getElementById('form-success');

if (bookingForm) {
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('form-name')?.value || '';
    const phone = document.getElementById('form-phone')?.value || '';
    const pkg = document.getElementById('form-package')?.value || '';
    const notes = document.getElementById('form-notes')?.value || '';

    // Save to localStorage
    const bookings = JSON.parse(localStorage.getItem('avex_bookings') || '[]');
    bookings.push({ name, phone, pkg, notes, date: new Date().toISOString() });
    localStorage.setItem('avex_bookings', JSON.stringify(bookings));

    // Show success message
    if (formSuccess) {
      formSuccess.classList.remove('hidden');
      setTimeout(() => {
        formSuccess.classList.add('hidden');
      }, 5000);
    }

    // Direct WhatsApp message formatting
    const text = encodeURIComponent(
      `Merhaba AVEX MEDYA, web sitenizden randevu almak istiyorum.\n\nİsim: ${name}\nTelefon: ${phone}\nPaket/Hizmet: ${pkg}\nNotlar: ${notes}`
    );
    const whatsappUrl = `https://wa.me/905555555555?text=${text}`;
    
    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
    bookingForm.reset();
  });
}

// Quick package select links
window.selectPackage = function(packageName) {
  const pkgSelect = document.getElementById('form-package');
  if (pkgSelect) {
    pkgSelect.value = packageName;
  }
  const randevuSec = document.getElementById('randevu');
  if (randevuSec) {
    randevuSec.scrollIntoView({ behavior: 'smooth' });
  }
};
