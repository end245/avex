import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Play } from 'lucide-react';
import { useApp } from '../context';

export default function Gallery() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const { data } = useApp();
  const [activeCategory, setActiveCategory] = useState('Tümü');

  const galleryItems = data?.gallery || [];
  const categories = ['Tümü', ...Array.from(new Set(galleryItems.map(item => item.category)))];

  const filteredItems = activeCategory === 'Tümü' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === activeCategory);

  return (
    <section id="galeri" className="py-32 bg-dark-900 min-h-screen">
      <div className="max-w-screen-2xl mx-auto px-4 md:px-8">
        <motion.div 
          ref={ref}
          className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-wider">
              Görsel <span className="text-gradient-gold">Şölen</span>
            </h2>
            <p className="text-white/50 text-lg font-light">Önceki işlerimizden seçmeler.</p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-2 rounded-full text-sm font-medium tracking-wide uppercase transition-all duration-300 ${
                  activeCategory === cat 
                    ? 'bg-gold-500 text-black' 
                    : 'glass text-white/60 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div 
          layout
          className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6"
        >
          <AnimatePresence>
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="relative group rounded-xl overflow-hidden break-inside-avoid cursor-pointer"
              >
                <img 
                  src={item.url} 
                  alt={item.category}
                  className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center backdrop-blur-sm">
                  {item.type === 'video' ? (
                    <div className="w-16 h-16 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center text-gold-500">
                      <Play className="w-6 h-6 ml-1" />
                    </div>
                  ) : (
                    <span className="text-white font-medium tracking-widest uppercase text-sm border-b border-gold-500 pb-1">
                      Görüntüle
                    </span>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
