import { Instagram, Youtube, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';
import AvexLogo from './AvexLogo';

export default function Footer() {
  return (
    <footer className="bg-black pt-20 pb-10 border-t border-white/10 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gold-500/50 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 flex flex-col items-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mb-8"
        >
          <AvexLogo className="w-64 max-w-full text-white" glow={false} />
        </motion.div>
        
        <div className="flex gap-6 mb-12">
          <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-gold-500 hover:text-black transition-all">
            <Instagram className="w-5 h-5" />
          </a>
          <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-gold-500 hover:text-black transition-all">
            <Youtube className="w-5 h-5" />
          </a>
          <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-gold-500 hover:text-black transition-all">
            <Twitter className="w-5 h-5" />
          </a>
        </div>
        
        <ul className="flex flex-wrap justify-center gap-8 mb-16 text-sm uppercase tracking-widest text-white/50">
          <li><a href="#hizmetler" className="hover:text-gold-500 transition-colors">Hizmetler</a></li>
          <li><a href="#fiyatlar" className="hover:text-gold-500 transition-colors">Paketler</a></li>
          <li><a href="#galeri" className="hover:text-gold-500 transition-colors">Galeri</a></li>
          <li><a href="#randevu" className="hover:text-gold-500 transition-colors">İletişim</a></li>
        </ul>
        
        <div className="text-center text-xs text-white/30 tracking-widest uppercase">
          &copy; {new Date().getFullYear()} AVEX MEDYA. Tüm hakları saklıdır.
        </div>
      </div>
    </footer>
  );
}
