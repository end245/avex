import { motion } from 'framer-motion';
import { useApp } from '../context';
import { Star } from 'lucide-react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';

export default function Testimonials() {
  const { data } = useApp();
  const testimonials = data?.testimonials || [];

  return (
    <section className="py-32 bg-black relative">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-wider">
            Referanslar
          </h2>
          <div className="w-24 h-1 bg-gold-500 mx-auto rounded-full" />
        </div>

        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={30}
          slidesPerView={1}
          pagination={{ clickable: true }}
          autoplay={{ delay: 5000, disableOnInteraction: false }}
          className="pb-16"
        >
          {testimonials.map((testi) => (
            <SwiperSlide key={testi.id}>
              <div className="glass-dark p-10 rounded-2xl text-center flex flex-col items-center">
                <div className="flex gap-1 mb-6 text-gold-500">
                  {[...Array(testi.rating)].map((_, i) => (
                    <Star key={i} className="fill-current w-5 h-5" />
                  ))}
                </div>
                <p className="text-xl md:text-2xl font-light italic text-white/80 leading-relaxed mb-8">
                  "{testi.text}"
                </p>
                <div className="text-gold-500 font-medium uppercase tracking-widest text-sm">
                  {testi.name}
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
