import React from 'react';

interface AvexLogoProps {
  className?: string;
  glow?: boolean;
}

export default function AvexLogo({ className = "w-full max-w-xl h-auto", glow = true }: AvexLogoProps) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      {glow && (
        <div className="absolute inset-0 blur-3xl bg-white/15 scale-90 pointer-events-none -z-10" />
      )}
      <svg 
        viewBox="0 0 720 230" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto drop-shadow-[0_0_20px_rgba(255,255,255,0.35)]"
      >
        {/* AVEX Wordmark */}
        <g fill="currentColor">
          {/* Letter A */}
          <polygon points="110,20 120,20 195,155 167,155 115,58 63,155 35,155" />

          {/* Letter V */}
          <polygon points="175,20 203,20 255,117 307,20 335,20 260,155 250,155" />

          {/* Letter E (Automotive rounded contour on left, crisp arms on right) */}
          <path d="M 500 20 L 405 20 C 378 20 365 32 365 52 L 365 123 C 365 143 378 155 405 155 L 500 155 L 500 131 L 407 131 C 398 131 392 125 392 116 L 392 98 L 480 98 L 480 77 L 392 77 L 392 59 C 392 50 398 44 407 44 L 500 44 Z" />

          {/* Letter X */}
          <polygon points="535,20 563,20 685,155 657,155" />
          <polygon points="685,20 657,20 535,155 563,155" />
        </g>

        {/* Bottom Accent: — M E D Y A — */}
        <g stroke="currentColor">
          {/* Left accent line */}
          <line x1="35" y1="200" x2="195" y2="200" strokeWidth="2.5" strokeLinecap="round" />

          {/* Right accent line */}
          <line x1="525" y1="200" x2="685" y2="200" strokeWidth="2.5" strokeLinecap="round" />
        </g>

        {/* MEDYA Typography */}
        <text 
          x="360" 
          y="209" 
          textAnchor="middle" 
          fill="currentColor" 
          fontFamily="'Syne', 'Manrope', system-ui, sans-serif" 
          fontSize="27" 
          fontWeight="700" 
          letterSpacing="18"
        >
          MEDYA
        </text>
      </svg>
    </div>
  );
}
