import { motion } from 'framer-motion';
import { Camera, Video, Navigation } from 'lucide-react';
import { useInView } from 'react-intersection-observer';

const services = [
  {
    icon: <Camera className="w-8 h-8" />,
    title: "İç Detaylı Çekim",
    desc: "Aracınızın iç mekanını en ince detayına kadar profesyonelce tanıtıyoruz.",
    video: "https://cdn.pixabay.com/video/2020/05/25/40141-425890250_large.mp4",
    normalPrice: "1.500₺",
    price: "1.000₺",
    discount: "%33 İNDİRİM!"
  },
  {
    icon: <Navigation className="w-8 h-8" />,
    title: "Drone Çekimi",
    desc: "Havadan etkileyici görüntülerle aracınızı farklı bir boyuta taşıyoruz.",
    video: "https://cdn.pixabay.com/video/2021/08/25/86267-592652157_large.mp4",
    normalPrice: "2.000₺",
    price: "1.500₺",
    discount: "%25 İNDİRİM!"
  },
  {
    icon: <Video className="w-8 h-8" />,
    title: "Yol Çekimi",
    desc: "Aracınızın performansını ve yol tutuşunu en iyi şekilde yansıtıyoruz.",
    video: "https://cdn.pixabay.com/video/2020/05/25/40140-425890249_large.mp4",
    normalPrice: "2.500₺",
    price: "2.000₺",
    discount: "%20 İNDİRİM!"
  }
];

export default function Services() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="hizmetler" className="py-32 bg-dark-900 relative">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div 
          ref={ref}
          className="text-center mb-20"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-wider">
            Premium <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold-500 to-yellow-200">Hizmetler</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto text-lg font-light">
            Otomobilinize hak ettiği değeri veren profesyonel medya prodüksiyon çözümleri.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="group relative h-[400px] rounded-2xl overflow-hidden glass p-8 flex flex-col justify-end transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)] hover:border-gold-500/50"
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
            >
              {/* Background Video (plays on hover) */}
              <div className="absolute inset-0 z-0 opacity-0 group-hover:opacity-40 transition-opacity duration-700">
                <video src={service.video} autoPlay loop muted playsInline className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/90 to-dark-900/40" />
              </div>
              
              <div className="relative z-10 flex flex-col h-full">
                <div className="flex items-start justify-between mb-auto">
                  <div className="w-16 h-16 rounded-full glass flex items-center justify-center text-gold-500 group-hover:scale-110 transition-transform duration-500 group-hover:bg-gold-500 group-hover:text-black">
                    {service.icon}
                  </div>
                  <div className="text-right">
                    <div className="text-white/50 line-through decoration-red-500 text-sm font-bold">{service.normalPrice}</div>
                    <div className="text-3xl font-bold text-white tracking-tighter">{service.price}</div>
                    <div className="text-gold-500 text-xs font-bold uppercase tracking-wider mt-1">{service.discount}</div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-2xl font-bold mb-3 tracking-wide">{service.title}</h3>
                  <p className="text-white/60 font-light leading-relaxed group-hover:text-white/90 transition-colors">
                    {service.desc}
                  </p>
                </div>
              </div>
              
              {/* Glow Effect */}
              <div className="absolute -inset-1 bg-gradient-to-r from-gold-500/0 via-gold-500/0 to-gold-500/0 group-hover:from-gold-500/20 group-hover:via-transparent group-hover:to-gold-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-[-1]" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
