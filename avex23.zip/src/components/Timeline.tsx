import { motion } from 'framer-motion';

const steps = [
  { title: "Randevu", desc: "İhtiyaçlarınızı belirliyor ve çekim tarihini planlıyoruz." },
  { title: "Çekim", desc: "Profesyonel ekipmanlarla aracınızı en iyi açılardan görüntülüyoruz." },
  { title: "Kurgu", desc: "Sinematik renk düzenlemesi ve premium kurgu işlemleri yapılıyor." },
  { title: "Teslim", desc: "Hazırlanan içerikler yüksek kalitede tarafınıza teslim ediliyor." }
];

export default function Timeline() {
  return (
    <section className="py-32 bg-dark-900 relative">
      <div className="max-w-5xl mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-wider">
            Çalışma <span className="text-gradient-gold">Sürecimiz</span>
          </h2>
        </div>

        <div className="relative">
          {/* Main Line */}
          <div className="absolute top-1/2 left-0 w-full h-[2px] bg-white/10 -translate-y-1/2 hidden md:block" />
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-4 relative z-10">
            {steps.map((step, i) => (
              <motion.div 
                key={i}
                className="relative flex flex-col items-center text-center"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: i * 0.2 }}
              >
                {/* Connector for mobile */}
                {i !== 0 && <div className="w-[2px] h-12 bg-white/10 mb-4 md:hidden" />}
                
                <div className="w-16 h-16 rounded-full bg-dark-900 border-2 border-gold-500 flex items-center justify-center text-2xl font-bold text-gold-500 mb-6 shadow-[0_0_20px_rgba(212,175,55,0.2)]">
                  {i + 1}
                </div>
                <h3 className="text-xl font-bold uppercase tracking-wider mb-3">{step.title}</h3>
                <p className="text-white/50 text-sm font-light leading-relaxed px-4">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
