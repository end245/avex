import { motion } from 'framer-motion';

const brands = [
  "BMW", "Mercedes-Benz", "Audi", "Porsche", "Volkswagen", "Renault", "Ford", "Lamborghini", "Ferrari", "Maserati"
];

export default function Brands() {
  return (
    <section className="py-20 bg-black border-y border-white/5 overflow-hidden flex flex-col items-center">
      <p className="text-white/30 text-sm tracking-[0.3em] uppercase mb-10 text-center">
        Güvenilen Markalar
      </p>
      
      <div className="relative w-full max-w-7xl mx-auto overflow-hidden flex">
        {/* Left/Right fading edges */}
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />
        
        {/* Marquee Track */}
        <motion.div 
          className="flex whitespace-nowrap gap-24 items-center"
          animate={{ x: [0, -1035] }} // rough width calculation, will repeat seamlessly
          transition={{ repeat: Infinity, ease: "linear", duration: 20 }}
        >
          {/* Duplicate for infinite effect */}
          {[...brands, ...brands, ...brands].map((brand, i) => (
            <div key={i} className="text-3xl md:text-4xl font-display font-bold text-white/20 hover:text-white/50 transition-colors duration-300">
              {brand}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
