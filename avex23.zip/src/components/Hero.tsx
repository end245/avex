import React, { useRef, Suspense, useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Environment, ContactShadows, useGLTF, Center, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import AvexLogo from './AvexLogo';

const CAR_MODELS = [
  { id: 'bmw', name: 'BMW M3 E30', file: '/car.glb', scale: 1.5 },
  { id: 'civic', name: 'Civic Type-R', file: '/car1.glb', scale: 1.5 },
];

// Preload models for instant display
useGLTF.preload('/car.glb');
useGLTF.preload('/car1.glb');

function CameraController() {
  const { camera } = useThree();
  const [isInteracting, setIsInteracting] = useState(false);
  
  const shots = React.useMemo(() => [
    { pos: new THREE.Vector3(0, 1.5, 8), lookAt: new THREE.Vector3(0, -0.5, 0), move: new THREE.Vector3(1, -0.2, -1) }, // Wide front directly
    { pos: new THREE.Vector3(2.2, -0.5, 2.5), lookAt: new THREE.Vector3(0, -1, 0), move: new THREE.Vector3(-0.5, 0.1, 0.3) }, // Close up wheel/side front
    { pos: new THREE.Vector3(5, 2, 5), lookAt: new THREE.Vector3(0, -0.5, 0), move: new THREE.Vector3(-1, 0.2, -1) }, // Wide front angle
    { pos: new THREE.Vector3(0, 2, -8), lookAt: new THREE.Vector3(0, -0.5, 0), move: new THREE.Vector3(-1, -0.2, 1) }, // Wide rear directly
    { pos: new THREE.Vector3(-3.5, 0.2, -3), lookAt: new THREE.Vector3(-0.5, -0.5, -1), move: new THREE.Vector3(0.5, 0.2, 0.5) }, // Rear left close
    { pos: new THREE.Vector3(3.5, -1, -2), lookAt: new THREE.Vector3(0, -0.5, 0), move: new THREE.Vector3(0, 0.2, 1) }, // Rear right low
  ], []);

  const currentShot = useRef(0);
  const currentLookAt = useRef(new THREE.Vector3());
  const interactionTimeout = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isInteracting) return;
    
    const changeShot = () => {
      currentShot.current = (currentShot.current + 1) % shots.length;
      const shot = shots[currentShot.current];
      camera.position.copy(shot.pos);
      currentLookAt.current.copy(shot.lookAt);
      camera.lookAt(currentLookAt.current);
    };

    // Initialize first shot if we just started
    const shot = shots[currentShot.current];
    camera.position.copy(shot.pos);
    currentLookAt.current.copy(shot.lookAt);
    camera.lookAt(currentLookAt.current);

    const interval = setInterval(changeShot, 3500); 
    
    return () => clearInterval(interval);
  }, [camera, shots, isInteracting]);

  useFrame((state, delta) => {
    if (isInteracting) return;
    const shot = shots[currentShot.current];
    camera.position.x += shot.move.x * delta * 0.2;
    camera.position.y += shot.move.y * delta * 0.2;
    camera.position.z += shot.move.z * delta * 0.2;
    camera.lookAt(currentLookAt.current);
  });

  const handleStart = () => {
    setIsInteracting(true);
    if (interactionTimeout.current) clearTimeout(interactionTimeout.current);
  };

  const handleEnd = () => {
    interactionTimeout.current = setTimeout(() => {
      setIsInteracting(false);
    }, 4000);
  };

  return (
    <OrbitControls 
      onStart={handleStart}
      onEnd={handleEnd}
      enableZoom={false} 
      enablePan={false} 
      minPolarAngle={Math.PI / 4} 
      maxPolarAngle={Math.PI / 2 - 0.05} 
    />
  );
}

// If the user uploads a car.glb into the public folder, this will load it.
function UserCarModel({ modelFile, scale = 1.5 }: { modelFile: string; scale?: number }) {
  // @ts-ignore
  const { scene } = useGLTF(modelFile);
  
  React.useEffect(() => {
    if (scene) {
      scene.traverse((child: any) => {
        if (child.isMesh) {
          child.frustumCulled = false;
        }
      });
    }
  }, [scene]);

  const meshRef = useRef<THREE.Group>(null);

  if (!scene) return null;

  return (
    <group ref={meshRef}>
      <Center position={[0, -1, 0]}>
        <primitive object={scene} scale={scale} />
      </Center>
    </group>
  );
}

class ErrorBoundary extends React.Component<{children: React.ReactNode, fallback: React.ReactNode}, {hasError: boolean}> {
  constructor(props: any) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error: unknown) {
    console.warn("3D scene error safely handled:", error);
  }
  render() {
    if (this.state.hasError) return this.props.fallback;
    return this.props.children;
  }
}

export default function Hero({ title, subtitle }: { title: string, subtitle: string }) {
  const [selectedModelIndex, setSelectedModelIndex] = useState(0);
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 1000], [0, 200]);
  const opacity = useTransform(scrollY, [0, 500], [1, 0]);
  
  return (
    <section className="relative h-screen w-full overflow-hidden bg-black flex items-center justify-center">
      {/* Background Video or Texture */}
      <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
        <video 
          autoPlay 
          muted 
          loop 
          playsInline
          className="w-full h-full object-cover"
          src="https://cdn.pixabay.com/video/2021/08/25/86266-592652156_large.mp4"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/50 to-black"></div>
        {/* Carbon Fiber Overlay Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03] mix-blend-overlay"
          style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'10\' height=\'10\' viewBox=\'0 0 10 10\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0 0h10v10H0V0zm5 5h5v5H5V5z\' fill=\'%23ffffff\' fill-rule=\'evenodd\'/%3E%3C/svg%3E")' }}
        />
      </div>

      {/* 3D Scene */}
      <div className="absolute inset-0 z-10 hidden md:block cursor-grab active:cursor-grabbing">
        <Canvas shadows camera={{ position: [5, 2, 8], fov: 45, near: 0.1, far: 1000 }}>
          <CameraController />
          <Environment preset="city" />
          <ambientLight intensity={0.2} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
          <ErrorBoundary fallback={null}>
            <Suspense fallback={null}>
              <UserCarModel 
                key={CAR_MODELS[selectedModelIndex].file}
                modelFile={CAR_MODELS[selectedModelIndex].file}
                scale={CAR_MODELS[selectedModelIndex].scale}
              />
            </Suspense>
          </ErrorBoundary>
          <ContactShadows position={[0, -1.5, 0]} opacity={0.4} scale={10} blur={2} far={4} />
        </Canvas>
      </div>

      {/* 3D Model Switcher Badge */}
      <div className="absolute top-8 right-8 z-30 hidden md:flex items-center gap-1.5 glass-dark px-3 py-1.5 rounded-full border border-white/10 text-xs">
        <span className="text-white/40 uppercase tracking-widest text-[10px] mr-1">Model:</span>
        {CAR_MODELS.map((car, idx) => (
          <button
            key={car.id}
            type="button"
            onClick={() => setSelectedModelIndex(idx)}
            className={`px-3 py-1 rounded-full text-xs transition-all cursor-pointer ${
              selectedModelIndex === idx
                ? 'bg-gold-500 text-black font-semibold shadow-[0_0_10px_rgba(212,175,55,0.4)]'
                : 'text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            {car.name}
          </button>
        ))}
      </div>

      {/* Content */}
      <motion.div 
        className="relative z-20 text-center px-4 mt-20 pointer-events-none"
        style={{ y: y1, opacity }}
      >
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
          className="flex justify-center mb-6 pointer-events-auto"
        >
          {title.trim().toUpperCase() === 'AVEX MEDYA' || title.trim().toUpperCase() === 'AVEX' ? (
            <AvexLogo className="w-full max-w-md md:max-w-2xl text-white" glow={true} />
          ) : (
            <h1 className="text-6xl md:text-9xl font-bold tracking-[0.15em] text-white">
              {title}
            </h1>
          )}
        </motion.div>
        <motion.p 
          className="text-lg md:text-2xl text-white/70 font-light tracking-widest uppercase mb-10 pointer-events-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8, ease: "easeOut" }}
        >
          {subtitle}
        </motion.p>
        
        <motion.div 
          className="flex flex-col md:flex-row items-center justify-center gap-6 pointer-events-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
        >
          <a href="#fiyatlar" className="relative group overflow-hidden glass px-8 py-4 rounded-full border border-gold-500/50 hover:bg-gold-500/10 transition-all duration-300">
            <span className="relative z-10 text-gold-500 font-medium tracking-wider uppercase text-sm">Fiyatları İncele</span>
            <div className="absolute inset-0 h-full w-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />
          </a>
          <a href="#randevu" className="relative group overflow-hidden bg-white text-black px-8 py-4 rounded-full hover:bg-gold-500 hover:text-white transition-all duration-300">
            <span className="relative z-10 font-medium tracking-wider uppercase text-sm">Randevu Al</span>
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
      >
        <span className="text-[10px] uppercase tracking-widest text-white/40">Keşfet</span>
        <div className="w-[1px] h-12 bg-white/20 overflow-hidden">
          <motion.div 
            className="w-full h-full bg-gold-500"
            animate={{ y: ['-100%', '100%'] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
          />
        </div>
      </motion.div>
    </section>
  );
}
