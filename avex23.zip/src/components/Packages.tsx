import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Check } from 'lucide-react';
import { useApp } from '../context';

export default function Packages() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });
  const { data } = useApp();

  const packages = data?.packages || [];

  return (
    <section id="fiyatlar" className="py-32 bg-black relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gold-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <motion.div 
          ref={ref}
          className="text-center mb-20"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-wider">
            Premium <span className="text-gradient-gold">Paketler</span>
          </h2>
        </motion.div>

        <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-4 xl:gap-8">
          {packages.map((pkg, index) => {
            const isGold = pkg.isPopular;
            return (
              <motion.div
                key={pkg.id}
                className={`relative w-full lg:w-1/3 rounded-2xl glass-dark p-8 md:p-10 transition-all duration-500 hover:-translate-y-4 group ${
                  isGold ? 'lg:-mt-8 lg:mb-8 border-gold-500/40 shadow-[0_0_40px_rgba(212,175,55,0.1)]' : 'border-white/10'
                }`}
                initial={{ opacity: 0, y: 50 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
              >
                {isGold && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <div className="bg-gradient-to-r from-gold-600 to-gold-400 text-black text-xs font-bold uppercase tracking-widest py-1.5 px-4 rounded-full shadow-[0_0_20px_rgba(212,175,55,0.4)] whitespace-nowrap">
                      En Çok Tercih Edilen
                    </div>
                  </div>
                )}
                
                <h3 className={`text-2xl font-bold mb-6 uppercase tracking-wide text-center pb-4 border-b ${isGold ? 'text-gold-500 border-gold-500/30' : 'text-white border-white/10'}`}>
                  {pkg.name}
                </h3>
                
                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-start text-white/90 font-light">
                      <Check className={`w-5 h-5 mr-3 shrink-0 ${isGold ? 'text-gold-500' : 'text-white/60'}`} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex flex-col items-center justify-center text-center space-y-2 mb-8 pt-6 border-t border-white/10">
                  {pkg.normalPrice && (
                    <div className="flex flex-col items-center">
                      <span className="text-sm text-white/50 uppercase tracking-widest">Normal Fiyat</span>
                      <span className="text-xl text-white/50 line-through decoration-red-500 decoration-2">{pkg.normalPrice}</span>
                    </div>
                  )}
                  <div className="flex flex-col items-center pt-2">
                    <span className="text-sm text-gold-500 uppercase tracking-widest">Paket Fiyat</span>
                    <span className="text-4xl md:text-5xl font-bold tracking-tighter text-white">{pkg.price}</span>
                  </div>
                  {pkg.discount && (
                    <div className="mt-4 bg-white/10 text-white font-bold py-2 px-6 rounded-sm uppercase tracking-wider text-sm border border-white/20">
                      {pkg.discount}
                    </div>
                  )}
                </div>
                
                <button className={`w-full py-4 rounded-full font-medium tracking-widest uppercase text-sm transition-all duration-300 ${
                  isGold 
                    ? 'bg-gold-500 text-black hover:bg-white hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]' 
                    : 'glass hover:bg-gold-500 hover:text-black hover:border-gold-500'
                }`}>
                  Seç
                </button>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          className="mt-20 flex flex-col md:flex-row items-center justify-center gap-8 max-w-4xl mx-auto glass-dark p-8 rounded-2xl border-gold-500/30"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-6 text-left">
            <div className="w-16 h-16 rounded-full bg-gold-500/10 flex items-center justify-center shrink-0 border border-gold-500/30 text-gold-500">
              <Check className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl md:text-2xl font-bold uppercase tracking-wider text-gold-500 mb-2">Her Pakette</h3>
              <p className="text-lg md:text-xl font-light text-white tracking-wide">Ücretsiz Kurgu ve Renk Düzenleme!</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
