import { useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram, MessageCircle, MapPin, Send } from 'lucide-react';
import { useApp } from '../context';

export default function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const { refreshData } = useApp();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      setStatus('success');
      setForm({ name: '', phone: '', email: '', message: '' });
      refreshData();
      
      setTimeout(() => setStatus('idle'), 3000);
    } catch(err) {
      setStatus('idle');
    }
  };

  return (
    <section id="randevu" className="py-32 bg-dark-900 relative">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 uppercase tracking-wider">
              İletişime <span className="text-gradient-gold">Geçin</span>
            </h2>
            <p className="text-white/60 mb-12 font-light text-lg">
              Randevu almak veya projeleriniz hakkında görüşmek için bizimle iletişime geçin.
            </p>
            
            <div className="space-y-8">
              <a href="https://wa.me/905555555555" target="_blank" rel="noreferrer" className="flex items-center group">
                <div className="w-14 h-14 rounded-full glass flex items-center justify-center text-gold-500 mr-6 group-hover:bg-gold-500 group-hover:text-black transition-colors duration-300">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-white/50 uppercase tracking-widest mb-1">WhatsApp</div>
                  <div className="text-xl font-light group-hover:text-gold-500 transition-colors">+90 (555) 555 55 55</div>
                </div>
              </a>
              
              <a href="https://instagram.com/avexmedya" target="_blank" rel="noreferrer" className="flex items-center group">
                <div className="w-14 h-14 rounded-full glass flex items-center justify-center text-gold-500 mr-6 group-hover:bg-gold-500 group-hover:text-black transition-colors duration-300">
                  <Instagram className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-white/50 uppercase tracking-widest mb-1">Instagram</div>
                  <div className="text-xl font-light group-hover:text-gold-500 transition-colors">@avexmedya</div>
                </div>
              </a>
              
              <div className="flex items-center">
                <div className="w-14 h-14 rounded-full glass flex items-center justify-center text-gold-500 mr-6">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-white/50 uppercase tracking-widest mb-1">Stüdyo</div>
                  <div className="text-xl font-light">Levent, İstanbul</div>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="glass-dark p-8 md:p-12 rounded-2xl border border-white/5"
          >
            <h3 className="text-2xl font-medium mb-8 uppercase tracking-widest text-center">Formu Doldurun</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">Ad Soyad</label>
                  <input 
                    type="text" 
                    required
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                    className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">Telefon</label>
                  <input 
                    type="tel" 
                    required
                    value={form.phone}
                    onChange={e => setForm({...form, phone: e.target.value})}
                    className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">E-posta</label>
                <input 
                  type="email" 
                  value={form.email}
                  onChange={e => setForm({...form, email: e.target.value})}
                  className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors"
                />
              </div>
              
              <div>
                <label className="block text-xs uppercase tracking-widest text-white/50 mb-2">Mesajınız</label>
                <textarea 
                  rows={4}
                  required
                  value={form.message}
                  onChange={e => setForm({...form, message: e.target.value})}
                  className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-gold-500 transition-colors resize-none"
                />
              </div>
              
              <button 
                type="submit" 
                disabled={status === 'submitting'}
                className="w-full py-4 bg-gold-500 text-black rounded-lg font-bold tracking-widest uppercase text-sm hover:bg-white transition-all flex items-center justify-center gap-2"
              >
                {status === 'idle' && <><Send className="w-4 h-4" /> Gönder</>}
                {status === 'submitting' && 'Gönderiliyor...'}
                {status === 'success' && 'Başarıyla Gönderildi!'}
              </button>
            </form>
          </motion.div>
          
        </div>
      </div>
    </section>
  );
}
