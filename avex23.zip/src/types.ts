export interface AppSettings {
  heroTitle: string;
  heroSubtitle: string;
}

export interface Package {
  id: string;
  name: string;
  price: string;
  normalPrice?: string;
  discount?: string;
  features: string[];
  isPopular: boolean;
}

export interface GalleryItem {
  id: string;
  type: 'photo' | 'video';
  url: string;
  category: string;
}

export interface Testimonial {
  id: string;
  name: string;
  text: string;
  rating: number;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  date: string;
}

export interface AppData {
  settings: AppSettings;
  packages: Package[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  messages: ContactMessage[];
  stats: {
    views: number;
    submissions: number;
  };
}
